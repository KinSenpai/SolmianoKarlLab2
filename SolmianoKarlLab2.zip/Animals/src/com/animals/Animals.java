package com.animals;

public class Animals {
		String Species;
		int Strength;
		String eat;
		int Population;
		
		double Result = 10.22;
		
		public Animals(String Species, int Strenght) {
			this.Species = Species;
			this.Strength = Strenght;
		}

public void setSpecies(String x) {
	this.Species = Species;
	}
public void setStrength(int y) {
	this.Strength = Strength;
	}
String getSpecies() {
	return this.Species;
	}
int getStrength() {
	return this.Strength;

 	}
public void result(double x) {
System.out.println("Winner is " + x);
	}

public Animals() {
}
void SetPopulation() {
	this.Population = Population;

	}
int GetPopulation() {
	return this.Population + 10;
	}
int GetPopulation1() {
	return this.Population + 0;
	}
}




