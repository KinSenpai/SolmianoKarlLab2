package com.animals;

public class Mammals extends Animals {
	double Result;
	public Mammals(String Species, int Strenght, double Result, String x) {
		super(Species, Strenght);
	}
	public void setResult(double Result) {
		this.Result = Result;
	}
	
	public double getResult() {
		return this.Result;
	}

	public void thisistheresult(double FinalResult) {
		System.out.println("Overall Strength  " + this.Result);

	}
	
	public static String Mammals2(String x) { 
		return x;
	
	}
 

}
