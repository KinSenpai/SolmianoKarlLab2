package com.animals;

public class Fight {

	public static void main(String[] args) {
		
		Animals predator = new Animals("T-Rex", 89);
		Animals challenger = new Animals("Triceretops", 90);

		System.out.println("This Animal species is " + predator.getSpecies() + " with the Strenght"
				+ " of " + predator.getStrength() +"\n");
		System.out.println("This Animal species is " + challenger.getSpecies() + " with the Strenght"
				+ " of " + challenger.getStrength()+"\n");
		
		
		Animals ecosystem = new Animals();
		
		System.out.println("The Predator's population is " + ecosystem.GetPopulation());
		System.out.println("The Herbivore's population is " + ecosystem.GetPopulation1());
		
		
		System.out.println(Mammals.Mammals2("-----End of Food Chain-----")); // -> OverLoading
	}
		
}
	
	
	


